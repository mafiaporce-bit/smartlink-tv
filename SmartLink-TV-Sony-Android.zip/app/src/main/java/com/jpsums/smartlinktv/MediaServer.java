package com.jpsums.smartlinktv;

import android.content.Context;
import android.net.Uri;
import android.os.ParcelFileDescriptor;

import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.ServerSocket;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import java.util.Collections;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * A tiny web server on the phone that hands ONE chosen file to the TV.
 * The address contains a random code, so other devices on the Wi-Fi can't browse your files.
 * Supports "Range" requests so the TV can jump around in a video.
 */
final class MediaServer {

    private final Context ctx;
    private final ExecutorService workers = Executors.newCachedThreadPool();
    private ServerSocket socket;

    private volatile Uri uri;
    private volatile String type = "application/octet-stream";
    private volatile long size = -1;
    private volatile String token;

    MediaServer(Context ctx) { this.ctx = ctx; }

    void start() throws IOException {
        socket = new ServerSocket(0);
        Thread t = new Thread(this::acceptLoop, "smartlink-media");
        t.setDaemon(true);
        t.start();
    }

    int port() { return socket.getLocalPort(); }

    String setFile(Uri u, String t, long s) {
        uri = u;
        type = t == null ? "application/octet-stream" : t;
        size = s;
        token = Long.toHexString(new SecureRandom().nextLong() & Long.MAX_VALUE)
                + Long.toHexString(new SecureRandom().nextLong() & Long.MAX_VALUE);
        return token;
    }

    void stop() {
        try { if (socket != null) socket.close(); } catch (IOException ignored) { }
        workers.shutdownNow();
    }

    private void acceptLoop() {
        while (socket != null && !socket.isClosed()) {
            try {
                final Socket s = socket.accept();
                workers.execute(() -> handle(s));
            } catch (IOException e) {
                break;
            } catch (Exception e) {
                // pool shut down
                break;
            }
        }
    }

    private static String readLine(InputStream in) throws IOException {
        StringBuilder sb = new StringBuilder();
        int c;
        while ((c = in.read()) != -1) {
            if (c == '\n') break;
            if (c != '\r') sb.append((char) c);
            if (sb.length() > 8192) break;
        }
        if (c == -1 && sb.length() == 0) return null;
        return sb.toString();
    }

    private static void writeHead(OutputStream out, String status, String... headers) throws IOException {
        StringBuilder sb = new StringBuilder("HTTP/1.1 ").append(status).append("\r\n");
        for (String h : headers) sb.append(h).append("\r\n");
        sb.append("Access-Control-Allow-Origin: *\r\n");
        sb.append("Connection: close\r\n\r\n");
        out.write(sb.toString().getBytes(StandardCharsets.US_ASCII));
    }

    private void handle(Socket sock) {
        ParcelFileDescriptor pfd = null;
        try (Socket s = sock) {
            s.setSoTimeout(30000);
            InputStream in = s.getInputStream();
            OutputStream out = new BufferedOutputStream(s.getOutputStream(), 64 * 1024);

            String request = readLine(in);
            if (request == null) return;
            String[] parts = request.split(" ");
            if (parts.length < 2) return;
            String method = parts[0].toUpperCase(Locale.ROOT);
            String path = parts[1];

            long start = 0, end = -1;
            boolean ranged = false;
            String line;
            while ((line = readLine(in)) != null && !line.isEmpty()) {
                String low = line.toLowerCase(Locale.ROOT);
                if (low.startsWith("range:") && low.contains("bytes=")) {
                    String r = low.substring(low.indexOf("bytes=") + 6).trim();
                    int dash = r.indexOf('-');
                    if (dash >= 0) {
                        try {
                            String a = r.substring(0, dash).trim(), b = r.substring(dash + 1).trim();
                            int comma = b.indexOf(',');
                            if (comma >= 0) b = b.substring(0, comma).trim();
                            if (!a.isEmpty()) start = Long.parseLong(a);
                            if (!b.isEmpty()) end = Long.parseLong(b);
                            ranged = true;
                        } catch (NumberFormatException ignored) { }
                    }
                }
            }

            Uri u = uri;
            String tok = token;
            if ("OPTIONS".equals(method)) {
                writeHead(out, "204 No Content",
                        "Access-Control-Allow-Methods: GET, HEAD, OPTIONS",
                        "Access-Control-Allow-Headers: Range, Content-Type");
                out.flush();
                return;
            }
            if (u == null || tok == null || !path.startsWith("/m/" + tok)) {
                writeHead(out, "404 Not Found", "Content-Length: 0");
                out.flush();
                return;
            }

            pfd = ctx.getContentResolver().openFileDescriptor(u, "r");
            if (pfd == null) {
                writeHead(out, "404 Not Found", "Content-Length: 0");
                out.flush();
                return;
            }
            long total = size > 0 ? size : pfd.getStatSize();
            if (total <= 0) {
                writeHead(out, "500 Internal Server Error", "Content-Length: 0");
                out.flush();
                return;
            }
            if (end < 0 || end >= total) end = total - 1;
            if (start < 0 || start > end) {
                writeHead(out, "416 Range Not Satisfiable", "Content-Range: bytes */" + total, "Content-Length: 0");
                out.flush();
                return;
            }
            long len = end - start + 1;

            if (ranged) {
                writeHead(out, "206 Partial Content",
                        "Content-Type: " + type,
                        "Content-Length: " + len,
                        "Content-Range: bytes " + start + "-" + end + "/" + total,
                        "Accept-Ranges: bytes");
            } else {
                writeHead(out, "200 OK",
                        "Content-Type: " + type,
                        "Content-Length: " + len,
                        "Accept-Ranges: bytes");
            }
            if ("HEAD".equals(method)) { out.flush(); return; }

            try (FileInputStream fis = new FileInputStream(pfd.getFileDescriptor())) {
                fis.getChannel().position(start);
                byte[] buf = new byte[64 * 1024];
                long left = len;
                while (left > 0) {
                    int n = fis.read(buf, 0, (int) Math.min(buf.length, left));
                    if (n < 0) break;
                    out.write(buf, 0, n);
                    left -= n;
                }
            }
            out.flush();
        } catch (Exception ignored) {
            // TV closed the connection (normal when it seeks) — nothing to do
        } finally {
            if (pfd != null) { try { pfd.close(); } catch (IOException ignored) { } }
        }
    }

    /** The phone's address on the home Wi-Fi, e.g. 192.168.0.23. Null when not on Wi-Fi. */
    static String wifiIp() {
        String fallback = null;
        try {
            for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                if (!ni.isUp() || ni.isLoopback()) continue;
                String name = ni.getName() == null ? "" : ni.getName();
                for (InetAddress a : Collections.list(ni.getInetAddresses())) {
                    if (a instanceof Inet4Address && a.isSiteLocalAddress()) {
                        if (name.startsWith("wlan")) return a.getHostAddress();
                        if (fallback == null && !name.startsWith("rmnet") && !name.startsWith("tun")) fallback = a.getHostAddress();
                    }
                }
            }
        } catch (Exception ignored) { }
        return fallback;
    }
}

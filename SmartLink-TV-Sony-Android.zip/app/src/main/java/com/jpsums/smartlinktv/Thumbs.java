package com.jpsums.smartlinktv;

import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.util.Base64;

import java.io.ByteArrayOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Small preview pictures for the seek bar: while you drag, the phone grabs a frame
 * from the video (the copy on the phone, not the TV) at the time under your finger.
 */
final class Thumbs {

    interface Out { void done(String id, long ms, String dataUrl); }

    private static final int WIDTH = 320;

    private final Context app;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final AtomicInteger latest = new AtomicInteger();
    private MediaMetadataRetriever reader;   // only touched on the worker thread
    private Uri file;

    Thumbs(Context c) { this.app = c.getApplicationContext(); }

    /** Call when the user picks a new file. Pass null for photos. */
    void setFile(final Uri videoUri) {
        latest.incrementAndGet();
        worker.execute(() -> {
            close();
            file = videoUri;
        });
    }

    /** Asks for the picture at a time. If you keep dragging, older requests are skipped. */
    void request(final String id, final long ms, final Out out) {
        final int mine = latest.incrementAndGet();
        worker.execute(() -> {
            if (mine != latest.get() || file == null) return;
            try {
                if (reader == null) {
                    reader = new MediaMetadataRetriever();
                    reader.setDataSource(app, file);
                }
                Bitmap frame;
                if (Build.VERSION.SDK_INT >= 27) {
                    frame = reader.getScaledFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC, WIDTH, WIDTH);
                } else {
                    frame = reader.getFrameAtTime(ms * 1000, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (frame != null && frame.getWidth() > WIDTH) {
                        int h = Math.max(1, Math.round(frame.getHeight() * (WIDTH / (float) frame.getWidth())));
                        Bitmap small = Bitmap.createScaledBitmap(frame, WIDTH, h, true);
                        frame.recycle();
                        frame = small;
                    }
                }
                if (frame == null) return;
                ByteArrayOutputStream jpg = new ByteArrayOutputStream();
                frame.compress(Bitmap.CompressFormat.JPEG, 70, jpg);
                frame.recycle();
                out.done(id, ms, "data:image/jpeg;base64," + Base64.encodeToString(jpg.toByteArray(), Base64.NO_WRAP));
            } catch (Throwable t) {
                // this video can't give previews — seeking still works without them
                close();
            }
        });
    }

    private void close() {
        if (reader != null) {
            try {
                reader.release();
            } catch (Throwable ignored) { }
            reader = null;
        }
    }
}

package com.jpsums.smartlinktv;

import android.content.Context;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;

import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;

import com.google.android.gms.cast.CastMediaControlIntent;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.MediaStatus;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Real casting. The TV's built-in Chromecast plays the file by itself,
 * so you can use other apps or lock the phone and it keeps playing.
 * All methods must be called on the main thread.
 */
final class CastHelper {

    interface Listener {
        void onDevices(JSONArray devices);
        void onState(JSONObject state);
    }

    private static CastHelper instance;

    static synchronized CastHelper get(Context c) {
        if (instance == null) instance = new CastHelper(c.getApplicationContext());
        return instance;
    }

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private CastContext cast;
    private MediaRouter router;
    private MediaRouteSelector selector;
    private Listener listener;
    private boolean scanning;

    private Uri fileUri;
    private String fileType = "";
    private String fileName = "";
    private long fileSize = -1;
    private boolean loadOnConnect;
    private String deviceName = "";
    private String title = "";
    private boolean photo;
    private String lastState = "idle";

    private CastHelper(Context app) { this.app = app; }

    boolean isReady() { return cast != null; }

    void setListener(Listener l) {
        listener = l;
        if (l != null && cast != null) pushStatus();
    }

    void setFile(Uri uri, String type, String name, long size) {
        fileUri = uri;
        fileType = type == null ? "video/mp4" : type;
        fileName = name == null ? "Video" : name;
        fileSize = size;
    }

    /** Returns an error message, or null when Cast is ready. */
    String init() {
        if (cast != null) return null;
        try {
            //noinspection deprecation
            cast = CastContext.getSharedInstance(app);
        } catch (Exception e) {
            cast = null;
            return "Google Cast isn't available on this phone. Update Google Play services.";
        }
        router = MediaRouter.getInstance(app);
        selector = new MediaRouteSelector.Builder()
                .addControlCategory(CastMediaControlIntent.categoryForCast(
                        CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
                .build();
        cast.getSessionManager().addSessionManagerListener(sessionListener, CastSession.class);
        CastSession s = cast.getSessionManager().getCurrentCastSession();
        if (s != null && s.isConnected()) onConnected(s);
        return null;
    }

    // ---------- finding Chromecast TVs ----------

    private final MediaRouter.Callback routerCallback = new MediaRouter.Callback() {
        @Override public void onRouteAdded(MediaRouter r, MediaRouter.RouteInfo route) { pushDevices(); }
        @Override public void onRouteRemoved(MediaRouter r, MediaRouter.RouteInfo route) { pushDevices(); }
        @Override public void onRouteChanged(MediaRouter r, MediaRouter.RouteInfo route) { pushDevices(); }
    };

    void startScan() {
        if (router == null) return;
        if (!scanning) {
            router.addCallback(selector, routerCallback, MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN);
            scanning = true;
        }
        pushDevices();
    }

    void stopScan() {
        if (router != null && scanning) {
            router.removeCallback(routerCallback);
            scanning = false;
        }
    }

    private void pushDevices() {
        if (router == null || listener == null) return;
        JSONArray list = new JSONArray();
        for (MediaRouter.RouteInfo r : router.getRoutes()) {
            if (r.isDefault() || !r.isEnabled() || !r.matchesSelector(selector)) continue;
            try {
                JSONObject o = new JSONObject();
                o.put("id", r.getId());
                o.put("name", String.valueOf(r.getName()));
                o.put("desc", r.getDescription() == null ? "" : r.getDescription());
                list.put(o);
            } catch (Exception ignored) { }
        }
        listener.onDevices(list);
    }

    // ---------- playing ----------

    void play(String routeId) {
        if (cast == null || router == null) { state("error", "Cast isn't ready yet. Try again."); return; }
        if (fileUri == null) { state("error", "Choose a video or photo first."); return; }
        MediaRouter.RouteInfo target = null;
        for (MediaRouter.RouteInfo r : router.getRoutes()) {
            if (r.getId().equals(routeId)) target = r;
        }
        CastSession s = cast.getSessionManager().getCurrentCastSession();
        boolean sameTv = target == null || router.getSelectedRoute().getId().equals(routeId);
        if (s != null && s.isConnected() && sameTv) {
            load(s);
            return;
        }
        if (target == null) { state("error", "TV not found. Make sure it's on and tap Search."); return; }
        loadOnConnect = true;
        deviceName = String.valueOf(target.getName());
        state("connecting", null);
        router.selectRoute(target);
    }

    private final SessionManagerListener<CastSession> sessionListener = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarting(CastSession s) { state("connecting", null); }
        @Override public void onSessionStarted(CastSession s, String sessionId) { onConnected(s); }
        @Override public void onSessionStartFailed(CastSession s, int error) {
            loadOnConnect = false;
            state("error", "Couldn't connect to the TV. Make sure it's on and on the same Wi‑Fi.");
        }
        @Override public void onSessionEnding(CastSession s) { }
        @Override public void onSessionEnded(CastSession s, int error) {
            CastService.stop(app);
            main.removeCallbacks(ticker);
            state("idle", null);
        }
        @Override public void onSessionResuming(CastSession s, String sessionId) { }
        @Override public void onSessionResumed(CastSession s, boolean wasSuspended) { onConnected(s); }
        @Override public void onSessionResumeFailed(CastSession s, int error) { }
        @Override public void onSessionSuspended(CastSession s, int reason) { }
    };

    private final RemoteMediaClient.Callback mediaCallback = new RemoteMediaClient.Callback() {
        @Override public void onStatusUpdated() { pushStatus(); }
    };

    private void onConnected(CastSession s) {
        if (s.getCastDevice() != null) deviceName = s.getCastDevice().getFriendlyName();
        RemoteMediaClient c = s.getRemoteMediaClient();
        if (c != null) {
            c.unregisterCallback(mediaCallback);
            c.registerCallback(mediaCallback);
        }
        if (loadOnConnect) load(s);
        else pushStatus();
        startTicker();
    }

    private void load(CastSession s) {
        loadOnConnect = false;
        RemoteMediaClient c = s.getRemoteMediaClient();
        if (c == null) { state("error", "The TV isn't ready. Try again."); return; }
        String url = CastService.serve(app, fileUri, fileType, fileSize, fileName, deviceName);
        if (url == null) { state("error", "Your phone must be on the same Wi‑Fi as the TV."); return; }
        photo = fileType.startsWith("image/");
        MediaMetadata md = new MediaMetadata(photo ? MediaMetadata.MEDIA_TYPE_PHOTO : MediaMetadata.MEDIA_TYPE_MOVIE);
        md.putString(MediaMetadata.KEY_TITLE, fileName);
        MediaInfo info = new MediaInfo.Builder(url)
                .setStreamType(photo ? MediaInfo.STREAM_TYPE_NONE : MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(fileType)
                .setMetadata(md)
                .build();
        title = fileName;
        c.unregisterCallback(mediaCallback);
        c.registerCallback(mediaCallback);
        state("loading", null);
        c.load(new MediaLoadRequestData.Builder().setMediaInfo(info).setAutoplay(true).build())
                .setResultCallback(result -> {
                    if (!result.getStatus().isSuccess()) {
                        state("error", "The TV couldn't play this file. MP4 videos and JPG/PNG photos work best.");
                    } else {
                        pushStatus();
                    }
                });
        startTicker();
    }

    void toggle() {
        RemoteMediaClient c = client();
        if (c != null) c.togglePlayback();
    }

    void stop() {
        loadOnConnect = false;
        main.removeCallbacks(ticker);
        if (cast != null) cast.getSessionManager().endCurrentSession(true);
        CastService.stop(app);
        state("idle", null);
    }

    // ---------- status to the screen ----------

    private RemoteMediaClient client() {
        if (cast == null) return null;
        CastSession s = cast.getSessionManager().getCurrentCastSession();
        return s != null && s.isConnected() ? s.getRemoteMediaClient() : null;
    }

    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (client() == null) return;
            if (listener != null) pushStatus();
            main.postDelayed(this, 1000);
        }
    };

    private void startTicker() {
        main.removeCallbacks(ticker);
        main.postDelayed(ticker, 1000);
    }

    void pushStatus() {
        RemoteMediaClient c = client();
        if (c == null) {
            if (!"connecting".equals(lastState) && !"error".equals(lastState)) state("idle", null);
            return;
        }
        String st;
        switch (c.getPlayerState()) {
            case MediaStatus.PLAYER_STATE_PLAYING: st = "playing"; break;
            case MediaStatus.PLAYER_STATE_PAUSED: st = "paused"; break;
            case MediaStatus.PLAYER_STATE_BUFFERING:
            case MediaStatus.PLAYER_STATE_LOADING: st = "buffering"; break;
            case MediaStatus.PLAYER_STATE_IDLE:
                int why = c.getIdleReason();
                if (why == MediaStatus.IDLE_REASON_FINISHED) st = "ended";
                else if (why == MediaStatus.IDLE_REASON_ERROR) st = "error";
                else st = "ready";
                break;
            default: st = "ready";
        }
        // A photo stays on screen without "playing", so show it as showing.
        if (photo && c.getMediaInfo() != null && ("ready".equals(st) || "playing".equals(st))) st = "showing";
        if (c.getMediaInfo() != null && title.isEmpty() && c.getMediaInfo().getMetadata() != null) {
            String t = c.getMediaInfo().getMetadata().getString(MediaMetadata.KEY_TITLE);
            if (t != null) title = t;
        }
        JSONObject o = base(st, "error".equals(st)
                ? "The TV couldn't play this file. MP4 videos and JPG/PNG photos work best." : null);
        try {
            o.put("position", c.getApproximateStreamPosition());
            o.put("duration", c.getStreamDuration());
        } catch (Exception ignored) { }
        lastState = st;
        emit(o);
    }

    private void state(String st, String msg) {
        lastState = st;
        emit(base(st, msg));
    }

    private JSONObject base(String st, String msg) {
        JSONObject o = new JSONObject();
        try {
            o.put("state", st);
            if (msg != null) o.put("msg", msg);
            o.put("device", deviceName);
            o.put("title", title);
            o.put("photo", photo);
            o.put("position", 0);
            o.put("duration", 0);
        } catch (Exception ignored) { }
        return o;
    }

    private void emit(JSONObject o) {
        if (listener != null) listener.onState(o);
    }

    static JSONObject error(String msg) {
        JSONObject o = new JSONObject();
        try {
            o.put("state", "error");
            o.put("msg", msg);
        } catch (Exception ignored) { }
        return o;
    }
}

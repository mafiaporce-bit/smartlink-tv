package com.jpsums.smartlinktv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ImageDecoder;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Build;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

/**
 * Free screen-size control for photos: the phone draws the photo onto a TV-shaped
 * 1920x1080 picture (Fit / Fill / Stretch, Zoom, Rotate) and the TV shows that.
 * Also turns Samsung HEIC photos into JPG so the TV can show them.
 */
final class PhotoRender {

    private static final int W = 1920, H = 1080, MAX_SIDE = 3840;

    private PhotoRender() { }

    static File render(Context c, Uri src, String fit, float zoom, int rot) throws IOException {
        Bitmap bmp = decode(c, src);
        if (bmp == null) throw new IOException("Can't read photo");

        Bitmap out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(out);
        canvas.drawColor(Color.BLACK);

        float bw = bmp.getWidth(), bh = bmp.getHeight();
        boolean sideways = rot % 180 != 0;
        float rw = sideways ? bh : bw, rh = sideways ? bw : bh;
        float sx, sy;
        if ("cover".equals(fit)) {
            sx = sy = Math.max(W / rw, H / rh);
        } else if ("fill".equals(fit)) {
            sx = W / rw;
            sy = H / rh;
        } else {
            sx = sy = Math.min(W / rw, H / rh);
        }
        sx *= zoom;
        sy *= zoom;

        Matrix m = new Matrix();
        m.postTranslate(-bw / 2f, -bh / 2f);
        m.postRotate(rot);
        m.postScale(sx, sy);
        m.postTranslate(W / 2f, H / 2f);
        canvas.drawBitmap(bmp, m, new Paint(Paint.FILTER_BITMAP_FLAG | Paint.ANTI_ALIAS_FLAG));
        bmp.recycle();

        File dir = c.getCacheDir();
        File[] old = dir.listFiles((d, name) -> name.startsWith("cast-photo-"));
        if (old != null) for (File f : old) { //noinspection ResultOfMethodCallIgnored
            f.delete(); }
        File file = new File(dir, "cast-photo-" + System.nanoTime() + ".jpg");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            out.compress(Bitmap.CompressFormat.JPEG, 90, fos);
        }
        out.recycle();
        return file;
    }

    private static Bitmap decode(Context c, Uri src) throws IOException {
        if (Build.VERSION.SDK_INT >= 28) {
            ImageDecoder.Source s = ImageDecoder.createSource(c.getContentResolver(), src);
            // ImageDecoder also turns the photo the right way up (EXIF) and reads HEIC.
            return ImageDecoder.decodeBitmap(s, (decoder, info, source) -> {
                int w = info.getSize().getWidth(), h = info.getSize().getHeight();
                int max = Math.max(w, h);
                if (max > MAX_SIDE) {
                    float k = (float) MAX_SIDE / max;
                    decoder.setTargetSize(Math.max(1, Math.round(w * k)), Math.max(1, Math.round(h * k)));
                }
                decoder.setAllocator(ImageDecoder.ALLOCATOR_SOFTWARE);
            });
        }
        BitmapFactory.Options bounds = new BitmapFactory.Options();
        bounds.inJustDecodeBounds = true;
        try (InputStream in = c.getContentResolver().openInputStream(src)) {
            BitmapFactory.decodeStream(in, null, bounds);
        }
        int sample = 1;
        while (Math.max(bounds.outWidth, bounds.outHeight) / sample > MAX_SIDE) sample *= 2;
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inSampleSize = sample;
        try (InputStream in = c.getContentResolver().openInputStream(src)) {
            return BitmapFactory.decodeStream(in, null, opts);
        }
    }
}

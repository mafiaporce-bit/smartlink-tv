package com.jpsums.smartlinktv;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;

/**
 * Keeps the app talking to the TV over Wi-Fi.
 *
 * When the Wi-Fi has no internet (a phone hotspot, a router with no line), Android quietly
 * sends app traffic over mobile data instead — and mobile data can't reach a TV in the room.
 * In that case this ties the whole app to the Wi-Fi. When the Wi-Fi does have internet,
 * the app is not tied (so Tailscale "Away" mode keeps working) — but requests to a TV in the
 * home still go straight over the Wi-Fi, see Net.
 */
final class WifiBinder {

    interface OnChange { void run(); }

    private static boolean started;
    private static Network bound;

    private WifiBinder() { }

    static synchronized void start(Context context, OnChange onChange) {
        if (started) return;
        final ConnectivityManager cm = (ConnectivityManager) context.getApplicationContext()
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        if (cm == null) return;
        Net.init(context);
        Diag.watch(cm);
        started = true;
        NetworkRequest req = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();
        try {
            cm.registerNetworkCallback(req, new ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(Network network) {
                    // Wi-Fi is (back) on: remember it and check the TV straight away
                    boolean isNew = Net.setWifi(network);
                    if (isNew) Diag.note("Wi-Fi connected");
                    if (isNew && onChange != null) onChange.run();
                }

                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                    Net.setWifi(network);
                    boolean noInternet = !caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
                    Diag.wifiInternet(!noInternet);
                    boolean changed = false;
                    synchronized (WifiBinder.class) {
                        if (noInternet && !network.equals(bound)) {
                            changed = cm.bindProcessToNetwork(network);
                            if (changed) bound = network;
                        } else if (!noInternet && network.equals(bound)) {
                            cm.bindProcessToNetwork(null);
                            bound = null;
                            changed = true;
                        }
                    }
                    if (changed && onChange != null) onChange.run();
                }

                @Override
                public void onLost(Network network) {
                    Net.lost(network);
                    Diag.note("Wi-Fi LOST");
                    Diag.wifiGone();
                    boolean changed = false;
                    synchronized (WifiBinder.class) {
                        if (network.equals(bound)) {
                            cm.bindProcessToNetwork(null);
                            bound = null;
                            changed = true;
                        }
                    }
                    if (changed && onChange != null) onChange.run();
                }
            });
        } catch (Exception e) {
            started = false;
        }
    }
}

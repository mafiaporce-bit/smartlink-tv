package com.jpsums.smartlinktv;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;

import java.net.DatagramSocket;
import java.net.HttpURLConnection;

import javax.net.SocketFactory;

/**
 * Remembers which of the phone's networks is the Wi-Fi, and sends everything meant for a TV
 * in the home straight through it.
 *
 * Why: Samsung phones can quietly move apps onto mobile data when the Wi-Fi looks busy
 * (for example while a movie is streaming to the TV). Mobile data can't reach a TV in the room,
 * so the remote would say "Can't reach TV" even though the Wi-Fi is fine.
 *
 * Tailscale ("Away") addresses are left alone and use the phone's normal route.
 */
final class Net {

    private static volatile Network wifi;
    private static volatile ConnectivityManager cm;

    private Net() { }

    static void init(Context c) {
        if (cm != null) return;
        cm = (ConnectivityManager) c.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        TvHttp.opener = (url, preferWifi) -> {
            Network n = wifi;
            if (preferWifi && n != null && TvHttp.isLan(url.getHost())) {
                try {
                    return (HttpURLConnection) n.openConnection(url);
                } catch (Exception e) {
                    // that Wi-Fi is gone — use the normal route below
                }
            }
            return (HttpURLConnection) url.openConnection();
        };
        TvHttp.socketPrep = Net::bind;
        TvHttp.label = Net::routeName;
    }

    /** @return true if this is a different Wi-Fi than the one we knew. */
    static boolean setWifi(Network n) {
        boolean changed = n != null && !n.equals(wifi);
        if (n != null) wifi = n;
        return changed;
    }

    static void lost(Network n) {
        if (n != null && n.equals(wifi)) wifi = null;
    }

    static boolean hasWifi() { return wifi != null; }

    static Network wifiNetwork() { return wifi; }

    static String nameOf(NetworkCapabilities caps) {
        if (caps == null) return "none";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) return "vpn";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) return "wifi";
        if (caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) return "mobile";
        return "other";
    }

    /** Ties a search / wake-up socket to the Wi-Fi. */
    static void bind(DatagramSocket s) {
        Network n = wifi;
        if (n == null || s == null) return;
        try {
            n.bindSocket(s);
        } catch (Exception ignored) {
            // carries on over the phone's normal route
        }
    }

    /** For the Samsung link: makes its connections over Wi-Fi. Null = use the normal route. */
    static SocketFactory socketFactory(String ip) {
        Network n = wifi;
        if (n == null || !TvHttp.isLan(ip)) return null;
        try {
            return n.getSocketFactory();
        } catch (Exception e) {
            return null;
        }
    }

    /** What the phone uses for normal traffic right now: "wifi", "mobile", "vpn", "other" or "none". */
    static String routeName() {
        try {
            ConnectivityManager m = cm;
            if (m == null) return "";
            Network n = m.getActiveNetwork();
            if (n == null) return "none";
            return nameOf(m.getNetworkCapabilities(n));
        } catch (Exception e) {
            return "";
        }
    }
}

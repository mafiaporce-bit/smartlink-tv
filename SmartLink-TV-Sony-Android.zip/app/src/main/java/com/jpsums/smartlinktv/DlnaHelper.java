package com.jpsums.smartlinktv;

import android.content.Context;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * "Play on TV" for TVs without Chromecast (Samsung, LG...). Uses the TV's own built-in
 * player (see DlnaClient). Reports to the screen in the same shape as CastHelper,
 * so the Play on TV sheet works the same for both kinds of TV.
 *
 * Public methods are called on the main thread; all network work runs on background threads.
 */
final class DlnaHelper {

    private static DlnaHelper instance;

    static synchronized DlnaHelper get(Context c) {
        if (instance == null) instance = new DlnaHelper(c.getApplicationContext());
        return instance;
    }

    private final Context app;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();      // play / pause / status, in order
    private final ExecutorService finder = Executors.newSingleThreadExecutor();  // searching never blocks playback
    private final Map<String, DlnaClient.Device> devices = Collections.synchronizedMap(new LinkedHashMap<>());
    private volatile CastHelper.Listener listener;
    private volatile JSONObject lastEmitted;

    // the file the user picked
    private volatile Uri fileUri;
    private volatile String fileType = "";
    private volatile String fileName = "";
    private volatile long fileSize = -1;
    private volatile String pFit = "contain";
    private volatile float pZoom = 1f;
    private volatile int pRot = 0;

    // what is playing now
    private volatile DlnaClient.Device active;
    private volatile int generation;          // goes up on every new play / stop, so old work knows to quit
    private volatile boolean photo;
    private volatile String title = "";
    private volatile String transport = "";
    private volatile long positionMs;
    private volatile long durationMs;
    private volatile boolean everPlayed;
    private volatile long startedAt;
    private int failures;

    private DlnaHelper(Context app) { this.app = app; }

    static boolean owns(String id) { return id != null && id.startsWith("dlna:"); }

    boolean isActive() { return active != null; }

    void setListener(CastHelper.Listener l) {
        listener = l;
        JSONObject last = lastEmitted;
        if (l != null && active != null && last != null) l.onState(last);
    }

    void setFile(Uri uri, String type, String name, long size) {
        fileUri = uri;
        fileType = type == null ? "video/mp4" : type;
        fileName = name == null ? "Video" : name;
        fileSize = size;
        pFit = "contain";
        pZoom = 1f;
        pRot = 0;
    }

    // ---------- finding TV players ----------

    void scan() {
        pushDevices();
        finder.execute(() -> {
            WifiManager.MulticastLock lock = null;
            try {
                WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
                if (wm != null) {
                    lock = wm.createMulticastLock("smartlink-dlna");
                    lock.setReferenceCounted(false);
                    lock.acquire();
                }
            } catch (Exception ignored) { }
            List<String> found;
            try {
                found = DlnaClient.search(2500);
            } finally {
                if (lock != null) {
                    try { lock.release(); } catch (Exception ignored) { }
                }
            }
            for (String location : found) {
                String id = "dlna:" + location;
                if (devices.containsKey(id)) continue;
                DlnaClient.Device d = DlnaClient.describe(location);
                if (d != null) devices.put(d.id, d);
            }
            // forget TVs that have gone, except the one that is playing
            DlnaClient.Device now = active;
            synchronized (devices) {
                devices.keySet().removeIf(id -> !found.contains(id.substring(5)) && (now == null || !now.id.equals(id)));
            }
            pushDevices();
        });
    }

    private void pushDevices() {
        final JSONArray list = new JSONArray();
        synchronized (devices) {
            for (DlnaClient.Device d : devices.values()) {
                try {
                    JSONObject o = new JSONObject();
                    o.put("id", d.id);
                    o.put("name", d.name.replaceFirst("^\\[TV\\]\\s*", ""));
                    String maker = d.maker.trim();
                    int sp = maker.indexOf(' ');
                    if (sp > 0) maker = maker.substring(0, sp);
                    o.put("desc", (maker.isEmpty() ? "Smart TV" : maker) + " · built-in TV player");
                    o.put("ip", d.ip);
                    o.put("dlna", true);
                    list.put(o);
                } catch (Exception ignored) { }
            }
        }
        main.post(() -> {
            CastHelper.Listener l = listener;
            if (l != null) l.onDevices(list);
        });
    }

    // ---------- playing ----------

    void play(String id) {
        if (fileUri == null) { emit("error", "Choose a video or photo first."); return; }
        final DlnaClient.Device d = devices.get(id);
        if (d == null) { emit("error", "TV not found. Tap Search and try again."); return; }
        final int gen = ++generation;
        active = d;
        photo = fileType.startsWith("image/");
        title = fileName;
        transport = "";
        positionMs = 0;
        durationMs = 0;
        emit("connecting", null);
        io.execute(() -> start(d, gen));
    }

    /** Changes how the photo fills the TV and sends it again. */
    void setPhotoView(String fit, float zoom, int rot) {
        if ("contain".equals(fit) || "cover".equals(fit) || "fill".equals(fit)) pFit = fit;
        pZoom = Math.max(0.5f, Math.min(3f, zoom));
        pRot = ((Math.round(rot / 90f) * 90) % 360 + 360) % 360;
        final DlnaClient.Device d = active;
        if (d == null || !photo) return;
        final int gen = ++generation;
        emit("loading", null);
        io.execute(() -> start(d, gen));
    }

    private void start(DlnaClient.Device d, int gen) {
        Uri uri = fileUri;
        String type = fileType;
        long size = fileSize;
        if (uri == null) return;
        if (photo) {
            // resize on the phone (Fit / Fill / Stretch / Zoom / Rotate) and turn HEIC into JPG
            try {
                File made = PhotoRender.render(app, uri, pFit, pZoom, pRot);
                uri = Uri.fromFile(made);
                type = "image/jpeg";
                size = made.length();
            } catch (Throwable ignored) {
                // send the original photo as it is
            }
        }
        if (gen != generation) return;
        String base = CastService.serve(app, uri, type, size, fileName, d.name.replaceFirst("^\\[TV\\]\\s*", ""));
        if (base == null) { fail(gen, "Your phone must be on the same Wi‑Fi as the TV."); return; }
        emit("loading", null);
        try {
            DlnaClient.load(d, base + "/" + DlnaClient.fileNameFor(type), type, fileName, size);
        } catch (DlnaClient.TvError e) {
            fail(gen, friendly(e));
            return;
        } catch (IOException e) {
            fail(gen, "Couldn't reach the TV. Make sure it's on and on the same Wi‑Fi. If the TV asks, choose Allow.");
            return;
        }
        if (gen != generation) return;
        startedAt = System.currentTimeMillis();
        everPlayed = false;
        failures = 0;
        if (photo) {
            emit("showing", null);
            return;
        }
        emit("buffering", null);
        schedulePoll(gen);
    }

    private static String friendly(DlnaClient.TvError e) {
        switch (e.code) {
            case 716:
                return "The TV couldn't open the file from your phone. Check both are on the same Wi‑Fi.";
            case 714:
            case 704:
            case 710:
                return "This TV can't play this type of file. MP4 videos and JPG photos work best.";
            case 701:
            case 705:
                return "The TV is busy. Close what's playing on the TV and try again.";
            default:
                return "The TV refused to play it (" + e.getMessage() + "). MP4 videos and JPG photos work best.";
        }
    }

    private void schedulePoll(final int gen) {
        main.postDelayed(() -> {
            if (gen == generation) io.execute(() -> poll(gen));
        }, 1000);
    }

    private void poll(int gen) {
        DlnaClient.Device d = active;
        if (gen != generation || d == null) return;
        try {
            DlnaClient.Status s = DlnaClient.status(d);
            failures = 0;
            if (gen != generation) return;
            transport = s.transport;
            if (s.durationMs > 0) durationMs = s.durationMs;
            String st;
            if ("PLAYING".equals(transport)) {
                everPlayed = true;
                positionMs = s.positionMs;
                st = "playing";
            } else if ("PAUSED_PLAYBACK".equals(transport)) {
                everPlayed = true;
                positionMs = s.positionMs;
                st = "paused";
            } else if ("TRANSITIONING".equals(transport)) {
                st = "buffering";
            } else {
                // STOPPED or NO_MEDIA_PRESENT
                if (everPlayed) {
                    // "Finished" only if it stopped near the end; otherwise someone stopped it on the TV.
                    long nearEnd = Math.max(2000, Math.min(5000, durationMs / 20));
                    boolean finished = durationMs > 0 && positionMs >= durationMs - nearEnd;
                    finish(gen, finished ? "ended" : "idle", null);
                    return;
                }
                if (System.currentTimeMillis() - startedAt > 20000) {
                    finish(gen, "error", "The TV didn't start playing. It may not support this file — MP4 works best.");
                    return;
                }
                st = "buffering";
            }
            emit(st, null);
        } catch (IOException e) {
            if (++failures >= 4) {
                finish(gen, "error", "Lost connection to the TV.");
                return;
            }
        }
        schedulePoll(gen);
    }

    void toggle() {
        final DlnaClient.Device d = active;
        if (d == null || photo) return;
        final int gen = generation;
        io.execute(() -> {
            if (gen != generation) return;
            try {
                if ("PLAYING".equals(transport)) {
                    DlnaClient.pause(d);
                    transport = "PAUSED_PLAYBACK";
                    emit("paused", null);
                } else {
                    DlnaClient.play(d);
                    transport = "PLAYING";
                    emit("playing", null);
                }
            } catch (IOException ignored) {
                // the next status check shows the real state
            }
        });
    }

    void stop() {
        final DlnaClient.Device d = active;
        if (d == null) return;
        generation++;
        active = null;
        CastService.stop(app);
        emit("idle", null);
        io.execute(() -> {
            try {
                DlnaClient.stop(d);
            } catch (IOException ignored) { }
        });
    }

    private void fail(int gen, String msg) {
        finish(gen, "error", msg);
    }

    private void finish(int gen, String st, String msg) {
        if (gen != generation) return;
        generation++;
        active = null;
        CastService.stop(app);
        emit(st, msg);
    }

    // ---------- status to the screen ----------

    private void emit(String st, String msg) {
        final JSONObject o = new JSONObject();
        try {
            DlnaClient.Device d = active;
            o.put("state", st);
            if (msg != null) o.put("msg", msg);
            if (d != null) o.put("device", d.name.replaceFirst("^\\[TV\\]\\s*", ""));
            o.put("title", title);
            o.put("photo", photo);
            o.put("fit", pFit);
            o.put("zoom", (double) pZoom);
            o.put("rot", pRot);
            o.put("position", positionMs);
            o.put("duration", durationMs);
            o.put("dlna", true);
        } catch (Exception ignored) { }
        lastEmitted = o;
        main.post(() -> {
            CastHelper.Listener l = listener;
            if (l != null) l.onState(o);
        });
    }
}

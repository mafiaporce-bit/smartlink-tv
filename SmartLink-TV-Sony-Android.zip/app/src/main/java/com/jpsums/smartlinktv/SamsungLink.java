package com.jpsums.smartlinktv;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Base64;

import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.concurrent.TimeUnit;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

/**
 * Talks to Samsung Smart TVs (2016 and newer) over the TV's remote-control WebSocket.
 * The TV uses its own self-signed certificate, so we remember that certificate the first
 * time (like Bluetooth pairing) and refuse to connect if a different device answers later.
 */
final class SamsungLink {

    interface Events { void on(JSONObject event); }

    private final Events events;
    private final SharedPreferences prefs;
    private final OkHttpClient client;
    private volatile String currentIp = "";
    private WebSocket ws;
    private int generation;

    SamsungLink(Context c, Events events) {
        this.events = events;
        this.prefs = c.getApplicationContext().getSharedPreferences("samsung_tvs", Context.MODE_PRIVATE);
        this.client = buildClient();
    }

    private OkHttpClient buildClient() {
        X509TrustManager tm = new X509TrustManager() {
            @Override public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                throw new CertificateException("Not used");
            }
            @Override public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
                if (chain == null || chain.length == 0) throw new CertificateException("No certificate");
                String fp = sha256(chain[0].getEncoded());
                String key = "cert_" + currentIp;
                String saved = prefs.getString(key, null);
                if (saved == null) prefs.edit().putString(key, fp).apply();
                else if (!saved.equals(fp)) throw new CertificateException("TV certificate changed");
            }
            @Override public X509Certificate[] getAcceptedIssuers() { return new X509Certificate[0]; }
        };
        OkHttpClient.Builder b = new OkHttpClient.Builder()
                .connectTimeout(6, TimeUnit.SECONDS)
                .readTimeout(0, TimeUnit.MILLISECONDS)
                .pingInterval(20, TimeUnit.SECONDS)
                .hostnameVerifier((host, session) -> true); // the TV's certificate has no hostname; we pin it above
        try {
            SSLContext ssl = SSLContext.getInstance("TLS");
            ssl.init(null, new TrustManager[]{tm}, new SecureRandom());
            b.sslSocketFactory(ssl.getSocketFactory(), tm);
        } catch (Exception ignored) { }
        return b.build();
    }

    private static String sha256(byte[] data) throws CertificateException {
        try {
            byte[] d = MessageDigest.getInstance("SHA-256").digest(data);
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            throw new CertificateException(e);
        }
    }

    /** Forget the remembered certificate (used by "Forget TV"). */
    void forget(String ip) {
        prefs.edit().remove("cert_" + ip).apply();
    }

    synchronized void connect(String ip, String token, String appName) {
        close();
        currentIp = ip;
        open(ip, token, appName, true, ++generation);
    }

    private void open(final String ip, final String token, final String appName, final boolean secure, final int gen) {
        String name = Base64.encodeToString(appName.getBytes(StandardCharsets.UTF_8), Base64.NO_WRAP);
        String url = (secure ? "wss://" + ip + ":8002" : "ws://" + ip + ":8001")
                + "/api/v2/channels/samsung.remote.control?name=" + name
                + (token != null && !token.isEmpty() ? "&token=" + token : "");
        Request req = new Request.Builder().url(url).build();
        ws = client.newWebSocket(req, new WebSocketListener() {
            private boolean opened;

            @Override public void onOpen(WebSocket socket, Response response) {
                if (gen != generation) { socket.close(1000, null); return; }
                opened = true;
                emit("open", null, secure ? "secure" : "plain");
            }

            @Override public void onMessage(WebSocket socket, String text) {
                if (gen == generation) emit("message", text, null);
            }

            @Override public void onClosing(WebSocket socket, int code, String reason) {
                socket.close(1000, null);
            }

            @Override public void onClosed(WebSocket socket, int code, String reason) {
                if (gen == generation) emit("closed", null, reason);
            }

            @Override public void onFailure(WebSocket socket, Throwable t, Response response) {
                if (gen != generation) return;
                String msg = t == null ? "" : String.valueOf(t.getMessage());
                // Older Samsung TVs (2016-2017) only have the plain port 8001.
                if (secure && !opened && !msg.contains("certificate changed")) {
                    open(ip, token, appName, false, gen);
                    return;
                }
                emit("failed", null, msg);
            }
        });
    }

    boolean send(String text) {
        WebSocket w = ws;
        return w != null && w.send(text);
    }

    synchronized void close() {
        generation++;
        if (ws != null) {
            try { ws.close(1000, null); } catch (Exception ignored) { }
            ws = null;
        }
    }

    private void emit(String type, String data, String msg) {
        JSONObject o = new JSONObject();
        try {
            o.put("type", type);
            if (data != null) o.put("data", data);
            if (msg != null) o.put("msg", msg);
        } catch (Exception ignored) { }
        events.on(o);
    }

    /** Wake-on-LAN "magic packet" so the TV can be turned on over Wi-Fi. */
    static boolean wake(String mac) {
        try {
            String hex = mac.replaceAll("[^0-9A-Fa-f]", "");
            if (hex.length() != 12) return false;
            byte[] m = new byte[6];
            for (int i = 0; i < 6; i++) m[i] = (byte) Integer.parseInt(hex.substring(i * 2, i * 2 + 2), 16);
            byte[] pkt = new byte[6 + 16 * 6];
            for (int i = 0; i < 6; i++) pkt[i] = (byte) 0xFF;
            for (int i = 6; i < pkt.length; i += 6) System.arraycopy(m, 0, pkt, i, 6);
            try (DatagramSocket s = new DatagramSocket()) {
                s.setBroadcast(true);
                InetAddress all = InetAddress.getByName("255.255.255.255");
                String ip = MediaServer.wifiIp();
                InetAddress subnet = null;
                if (ip != null) subnet = InetAddress.getByName(ip.substring(0, ip.lastIndexOf('.')) + ".255");
                for (int round = 0; round < 3; round++) {
                    s.send(new DatagramPacket(pkt, pkt.length, all, 9));
                    s.send(new DatagramPacket(pkt, pkt.length, all, 7));
                    if (subnet != null) s.send(new DatagramPacket(pkt, pkt.length, subnet, 9));
                }
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }
}

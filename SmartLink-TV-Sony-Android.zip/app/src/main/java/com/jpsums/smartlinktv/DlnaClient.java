package com.jpsums.smartlinktv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Talks to a TV's built-in media player (DLNA / UPnP "MediaRenderer").
 * Samsung TVs have no Chromecast, but they all have this player: the phone tells the TV
 * "play the video at this address" and the TV plays it by itself.
 *
 * Plain Java only (no Android classes) so it can be tested on a computer.
 * Every method here does network work — never call from the main thread.
 */
final class DlnaClient {

    private DlnaClient() { }

    /** One TV player found on the Wi-Fi. */
    static final class Device {
        String id = "";         // "dlna:" + description address
        String name = "";       // e.g. "[TV] Samsung Q80 Series (55)"
        String maker = "";      // e.g. "Samsung Electronics"
        String model = "";
        String ip = "";
        String controlUrl = ""; // where play / pause / stop commands go
        String service = "urn:schemas-upnp-org:service:AVTransport:1";
    }

    /** What the TV is doing right now. */
    static final class Status {
        String transport = "";  // PLAYING, PAUSED_PLAYBACK, STOPPED, TRANSITIONING, NO_MEDIA_PRESENT
        long positionMs;
        long durationMs;
    }

    /** The TV answered, but said no. */
    static final class TvError extends IOException {
        final int code;
        TvError(int code, String message) {
            super(message);
            this.code = code;
        }
    }

    // ---------- finding TVs ----------

    /** Asks the Wi-Fi "any media players here?" and returns their description addresses. */
    static List<String> search(int millis) {
        return search("239.255.255.250", 1900, millis);
    }

    static List<String> search(String host, int port, int millis) {
        Set<String> found = new LinkedHashSet<>();
        String[] targets = {
                "urn:schemas-upnp-org:service:AVTransport:1",
                "urn:schemas-upnp-org:device:MediaRenderer:1"
        };
        try (DatagramSocket sock = new DatagramSocket()) {
            sock.setSoTimeout(400);
            InetAddress group = InetAddress.getByName(host);
            for (int round = 0; round < 2; round++) {
                for (String st : targets) {
                    String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: "
                            + st + "\r\n\r\n";
                    byte[] d = msg.getBytes(StandardCharsets.US_ASCII);
                    sock.send(new DatagramPacket(d, d.length, group, port));
                }
            }
            long end = System.currentTimeMillis() + millis;
            byte[] buf = new byte[4096];
            while (System.currentTimeMillis() < end) {
                try {
                    DatagramPacket pk = new DatagramPacket(buf, buf.length);
                    sock.receive(pk);
                    String r = new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8);
                    for (String line : r.split("\r?\n")) {
                        if (line.toLowerCase(Locale.ROOT).startsWith("location:")) {
                            String loc = line.substring(9).trim();
                            if (loc.startsWith("http://")) found.add(loc);
                        }
                    }
                } catch (SocketTimeoutException t) {
                    // keep listening until time is up
                }
            }
        } catch (Exception ignored) { }
        return new ArrayList<>(found);
    }

    /** Reads a TV's description. Returns null if it has no media player we can control. */
    static Device describe(String location) {
        try {
            URL base = new URL(location);
            String xml = http(location, "GET", null, null, 4000).body;
            Device d = new Device();
            d.id = "dlna:" + location;
            d.ip = base.getHost();
            d.name = unescape(tag(xml, "friendlyName"));
            d.maker = unescape(tag(xml, "manufacturer"));
            d.model = unescape(tag(xml, "modelName"));
            String urlBase = tag(xml, "URLBase");
            Matcher m = Pattern.compile("<service>(.*?)</service>", Pattern.DOTALL).matcher(xml);
            while (m.find()) {
                String block = m.group(1);
                String type = tag(block, "serviceType");
                if (type.contains(":service:AVTransport:")) {
                    String control = unescape(tag(block, "controlURL"));
                    if (control.isEmpty()) continue;
                    URL root = urlBase.isEmpty() ? base : new URL(urlBase.trim());
                    d.controlUrl = new URL(root, control).toString();
                    d.service = type.trim();
                    break;
                }
            }
            if (d.controlUrl.isEmpty()) return null;
            if (d.name.isEmpty()) d.name = d.model.isEmpty() ? "TV" : d.model;
            return d;
        } catch (Exception e) {
            return null;
        }
    }

    // ---------- playing ----------

    /** Tells the TV which file to play (it starts loading it from the phone). */
    static void setUri(Device d, String url, String mime, String title, long size) throws IOException {
        boolean image = mime.startsWith("image/");
        String didl = "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\""
                + " xmlns:dc=\"http://purl.org/dc/elements/1.1/\""
                + " xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\""
                + " xmlns:dlna=\"urn:schemas-dlna-org:metadata-1-0/\""
                + " xmlns:sec=\"http://www.sec.co.kr/\">"
                + "<item id=\"0\" parentID=\"-1\" restricted=\"1\">"
                + "<dc:title>" + escape(title == null || title.isEmpty() ? "SmartLink TV" : title) + "</dc:title>"
                + "<upnp:class>" + (image ? "object.item.imageItem.photo" : "object.item.videoItem") + "</upnp:class>"
                + "<res protocolInfo=\"http-get:*:" + mime + ":" + features(mime) + "\""
                + (size > 0 ? " size=\"" + size + "\"" : "") + ">" + escape(url) + "</res>"
                + "</item></DIDL-Lite>";
        soap(d, "SetAVTransportURI",
                "<CurrentURI>" + escape(url) + "</CurrentURI>"
                        + "<CurrentURIMetaData>" + escape(didl) + "</CurrentURIMetaData>");
    }

    static void play(Device d) throws IOException {
        soap(d, "Play", "<Speed>1</Speed>");
    }

    /**
     * The whole "play this on the TV" step: stop whatever is on, hand over the new file, press play.
     * TVs are often busy for a moment after getting a new file, so Play is tried a few times.
     */
    static void load(Device d, String url, String mime, String title, long size) throws IOException {
        try {
            stop(d);
        } catch (IOException ignored) {
            // nothing was playing
        }
        setUri(d, url, mime, title, size);
        IOException last = null;
        for (int attempt = 0; attempt < 5; attempt++) {
            try {
                play(d);
                return;
            } catch (TvError e) {
                last = e;
                // 716 = the TV could not open the file; waiting won't help
                if (e.code == 716 || e.code == 714) throw e;
            }
            try {
                Thread.sleep(600);
            } catch (InterruptedException ie) {
                Thread.currentThread().interrupt();
                throw new IOException("interrupted");
            }
        }
        if (last != null) throw last;
    }

    static void pause(Device d) throws IOException {
        soap(d, "Pause", "");
    }

    /** Jumps to a time in the video. */
    static void seek(Device d, long ms) throws IOException {
        long s = Math.max(0, ms / 1000);
        String target = String.format(Locale.ROOT, "%d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60);
        soap(d, "Seek", "<Unit>REL_TIME</Unit><Target>" + target + "</Target>");
    }

    static void stop(Device d) throws IOException {
        soap(d, "Stop", "");
    }

    static Status status(Device d) throws IOException {
        Status s = new Status();
        // short wait: this runs every second, and a TV that was switched off should be noticed quickly
        s.transport = tag(soap(d, "GetTransportInfo", "", 3000), "CurrentTransportState").trim();
        try {
            String pos = soap(d, "GetPositionInfo", "", 3000);
            s.positionMs = clock(tag(pos, "RelTime"));
            s.durationMs = clock(tag(pos, "TrackDuration"));
        } catch (IOException ignored) {
            // some TVs don't report position — playing still works
        }
        return s;
    }

    /** The DLNA "what can you do with this file" line (seek by byte range, streaming). */
    static String features(String mime) {
        if (mime != null && mime.startsWith("image/")) {
            return ("image/jpeg".equals(mime) ? "DLNA.ORG_PN=JPEG_LRG;" : "")
                    + "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=00D00000000000000000000000000000";
        }
        return "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000";
    }

    /** A file ending the TV recognises, e.g. "video.mp4". */
    static String fileNameFor(String mime) {
        String m = mime == null ? "" : mime.toLowerCase(Locale.ROOT);
        if (m.startsWith("image/")) {
            if (m.contains("png")) return "photo.png";
            return "photo.jpg";
        }
        if (m.contains("matroska")) return "video.mkv";
        if (m.contains("quicktime")) return "video.mov";
        if (m.contains("webm")) return "video.webm";
        if (m.contains("3gpp")) return "video.3gp";
        if (m.contains("avi") || m.contains("msvideo")) return "video.avi";
        if (m.contains("mp2t")) return "video.ts";
        return "video.mp4";
    }

    // ---------- plumbing ----------

    private static final class Reply {
        int status;
        String body = "";
    }

    private static String soap(Device d, String action, String args) throws IOException {
        return soap(d, action, args, 6000);
    }

    private static String soap(Device d, String action, String args, int timeout) throws IOException {
        String body = "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\""
                + " s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>"
                + "<u:" + action + " xmlns:u=\"" + d.service + "\"><InstanceID>0</InstanceID>" + args
                + "</u:" + action + "></s:Body></s:Envelope>";
        Reply r = http(d.controlUrl, "POST", body, "\"" + d.service + "#" + action + "\"", timeout);
        if (r.status >= 200 && r.status < 300) return r.body;
        int code = 0;
        try {
            code = Integer.parseInt(tag(r.body, "errorCode").trim());
        } catch (NumberFormatException ignored) { }
        String why = unescape(tag(r.body, "errorDescription")).trim();
        throw new TvError(code == 0 ? r.status : code, why.isEmpty() ? "TV error " + r.status : why);
    }

    private static Reply http(String url, String method, String body, String soapAction, int timeout) throws IOException {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        try {
            c.setConnectTimeout(timeout);
            c.setReadTimeout(timeout);
            c.setRequestMethod(method);
            c.setRequestProperty("Connection", "close");
            c.setRequestProperty("User-Agent", "SmartLinkTV/2 UPnP/1.0 DLNADOC/1.50");
            if (body != null) {
                byte[] data = body.getBytes(StandardCharsets.UTF_8);
                c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
                if (soapAction != null) c.setRequestProperty("SOAPACTION", soapAction);
                c.setDoOutput(true);
                c.setFixedLengthStreamingMode(data.length);
                try (OutputStream os = c.getOutputStream()) {
                    os.write(data);
                }
            }
            Reply r = new Reply();
            r.status = c.getResponseCode();
            InputStream is = r.status >= 400 ? c.getErrorStream() : c.getInputStream();
            if (is != null) {
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = is.read(buf)) != -1) {
                    out.write(buf, 0, n);
                    if (out.size() > 2_000_000) break;
                }
                is.close();
                r.body = out.toString("UTF-8");
            }
            return r;
        } finally {
            c.disconnect();
        }
    }

    /** Text inside the first &lt;name&gt;…&lt;/name&gt; (also matches a prefix like u:name). */
    static String tag(String xml, String name) {
        if (xml == null) return "";
        Matcher m = Pattern.compile("<(?:[A-Za-z0-9_]+:)?" + name + "(?:\\s[^>]*)?>(.*?)</(?:[A-Za-z0-9_]+:)?" + name + ">",
                Pattern.DOTALL).matcher(xml);
        return m.find() ? m.group(1) : "";
    }

    /** "0:01:23" or "00:01:23.500" -> milliseconds. Anything else -> 0. */
    static long clock(String t) {
        if (t == null) return 0;
        String[] p = t.trim().split(":");
        if (p.length != 3) return 0;
        try {
            double sec = Double.parseDouble(p[2]);
            return (Long.parseLong(p[0]) * 3600 + Long.parseLong(p[1]) * 60) * 1000 + Math.round(sec * 1000);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    static String escape(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    static String unescape(String s) {
        return s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&");
    }
}

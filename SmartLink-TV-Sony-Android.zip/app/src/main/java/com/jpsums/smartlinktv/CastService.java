package com.jpsums.smartlinktv;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;

import java.io.IOException;

/**
 * Keeps the phone handing the video to the TV while the screen is off
 * or while you use other apps. Shows a "Playing on TV" notification with Stop.
 */
public class CastService extends Service {

    static final String ACTION_STOP = "com.jpsums.smartlinktv.STOP_CAST";
    private static final String CHANNEL = "casting";
    private static final int NOTIF_ID = 7;

    private static MediaServer server;
    private static String nowTitle = "";
    private static String nowDevice = "";

    private PowerManager.WakeLock wake;
    private WifiManager.WifiLock wifi;

    /** Starts the service (if needed) and returns the address the TV should play from. */
    static synchronized String serve(Context c, Uri uri, String type, long size, String title, String device) {
        String ip = MediaServer.wifiIp();
        if (ip == null) return null;
        try {
            if (server == null) {
                server = new MediaServer(c.getApplicationContext());
                server.start();
            }
        } catch (IOException e) {
            server = null;
            return null;
        }
        String token = server.setFile(uri, type, size);
        nowTitle = title == null ? "" : title;
        nowDevice = device == null ? "" : device;
        Intent i = new Intent(c, CastService.class);
        if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
        else c.startService(i);
        return "http://" + ip + ":" + server.port() + "/m/" + token;
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, CastService.class));
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            CastHelper.get(this).stop();
            stopSelf();
            return START_NOT_STICKY;
        }
        showNotification();
        acquireLocks();
        return START_NOT_STICKY;
    }

    private void showNotification() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            if (nm != null) {
                nm.createNotificationChannel(new NotificationChannel(CHANNEL, "Playing on TV", NotificationManager.IMPORTANCE_LOW));
            }
            b = new Notification.Builder(this, CHANNEL);
        } else {
            b = new Notification.Builder(this);
        }
        Intent openIntent = new Intent(this, MainActivity.class);
        openIntent.addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent open = PendingIntent.getActivity(this, 0, openIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Intent stopIntent = new Intent(this, CastService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stop = PendingIntent.getService(this, 1, stopIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        @SuppressWarnings("deprecation")
        Notification.Action stopAction = new Notification.Action.Builder(R.drawable.ic_stat_cast, "Stop", stop).build();

        Notification n = b.setSmallIcon(R.drawable.ic_stat_cast)
                .setContentTitle(nowDevice.isEmpty() ? "Playing on TV" : "Playing on " + nowDevice)
                .setContentText(nowTitle)
                .setOngoing(true)
                .setContentIntent(open)
                .addAction(stopAction)
                .build();

        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK);
        } else {
            startForeground(NOTIF_ID, n);
        }
    }

    @SuppressWarnings("deprecation")
    private void acquireLocks() {
        try {
            if (wake == null) {
                PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
                if (pm != null) {
                    wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "smartlink:cast");
                    wake.setReferenceCounted(false);
                    wake.acquire(6 * 60 * 60 * 1000L);
                }
            }
            if (wifi == null) {
                WifiManager wm = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
                if (wm != null) {
                    wifi = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "smartlink:cast");
                    wifi.setReferenceCounted(false);
                    wifi.acquire();
                }
            }
        } catch (Exception ignored) { }
    }

    @Override
    public void onDestroy() {
        try { if (wake != null && wake.isHeld()) wake.release(); } catch (Exception ignored) { }
        try { if (wifi != null && wifi.isHeld()) wifi.release(); } catch (Exception ignored) { }
        synchronized (CastService.class) {
            if (server != null) {
                server.stop();
                server = null;
            }
        }
        super.onDestroy();
    }
}

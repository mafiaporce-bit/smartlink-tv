package com.jpsums.smartlinktv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * SmartLink TV — the remote screen is the HTML page in assets/index.html.
 * The page talks to the Sony TV through the "Native" bridge below, because a
 * normal web page is not allowed to send requests to devices on your Wi-Fi.
 */
public class MainActivity extends Activity {

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    /** Remote key presses go one after another on their own thread, so they stay in order and fast. */
    private final ExecutorService keys = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private static final int REQ_PICK = 41;

    /** Sends casting updates to the page. */
    private final CastHelper.Listener castListener = new CastHelper.Listener() {
        @Override public void onDevices(JSONArray devices) {
            js("window.__castDevices && window.__castDevices(" + devices + ")");
        }
        @Override public void onState(JSONObject state) {
            js("window.__castState && window.__castState(" + state + ")");
        }
    };

    private void js(final String code) {
        main.post(() -> { if (web != null) web.evaluateJavascript(code, null); });
    }

    private void askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33
                && checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"}, 9);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PICK) return;
        if (resultCode != RESULT_OK || data == null || data.getData() == null) {
            js("window.__castPicked && window.__castPicked(null)");
            return;
        }
        Uri uri = data.getData();
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) { }
        String type = getContentResolver().getType(uri);
        if (type == null) type = "video/mp4";
        String name = type.startsWith("image/") ? "Photo" : "Video";
        long size = -1;
        try (Cursor c = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                int si = c.getColumnIndex(OpenableColumns.SIZE);
                if (ni >= 0 && !c.isNull(ni)) name = c.getString(ni);
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si);
            }
        } catch (Exception ignored) { }
        CastHelper.get(this).setFile(uri, type, name, size);
        JSONObject o = new JSONObject();
        try {
            o.put("name", name);
            o.put("type", type);
            o.put("size", size);
        } catch (Exception ignored) { }
        js("window.__castPicked && window.__castPicked(" + o + ")");
    }

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.setBackgroundColor(0xFF0D1117);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Native");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onNativeBack && window.onNativeBack()) ? 'yes' : 'no'", value -> {
            if (value == null || !value.contains("yes")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null);
    }

    @Override
    protected void onDestroy() {
        CastHelper h = CastHelper.get(this);
        h.stopScan();
        h.setListener(null);
        pool.shutdownNow();
        keys.shutdownNow();
        super.onDestroy();
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) out.write(buf, 0, n);
        is.close();
        return out.toString("UTF-8");
    }

    private class Bridge {

        /** HTTP request to the TV. Result comes back via window.__nativeDone(id, status, body). */
        @JavascriptInterface
        public void request(final String id, final String url, final String method,
                            final String headersJson, final String body) {
            ExecutorService runner = url != null && url.endsWith("/sony/ircc") ? keys : pool;
            runner.execute(() -> {
                int status = -1;
                String text = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(4000);
                    c.setReadTimeout(7000);
                    c.setRequestMethod(method == null || method.isEmpty() ? "POST" : method);
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                    if (body != null && !body.isEmpty()) {
                        byte[] data = body.getBytes(StandardCharsets.UTF_8);
                        c.setDoOutput(true);
                        c.setFixedLengthStreamingMode(data.length);
                        try (OutputStream os = c.getOutputStream()) { os.write(data); }
                    }
                    status = c.getResponseCode();
                    InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (is != null) text = readAll(is);
                } catch (Exception e) {
                    status = -1;
                    text = String.valueOf(e.getMessage());
                    if (c != null) c.disconnect();
                }
                // No disconnect() on success: the connection is kept open and reused for the next press.
                final String js = "window.__nativeDone(" + JSONObject.quote(id) + "," + status + ","
                        + JSONObject.quote(text) + ")";
                main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
            });
        }

        @JavascriptInterface
        public void haptic() {
            main.post(() -> { if (web != null) web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); });
        }

        @JavascriptInterface
        public boolean isApp() { return true; }

        /** Looks for Sony TVs on the Wi-Fi (SSDP). Result: window.__nativeFound(id, ["192.168.0.148", ...]). */
        @JavascriptInterface
        public void discover(final String id) {
            pool.execute(() -> {
                LinkedHashSet<String> ips = new LinkedHashSet<>();
                WifiManager.MulticastLock lock = null;
                try {
                    WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    if (wm != null) {
                        lock = wm.createMulticastLock("smartlink");
                        lock.setReferenceCounted(false);
                        lock.acquire();
                    }
                } catch (Exception ignored) { }
                try (DatagramSocket sock = new DatagramSocket()) {
                    sock.setSoTimeout(500);
                    InetAddress group = InetAddress.getByName("239.255.255.250");
                    String[] targets = { "urn:schemas-sony-com:service:ScalarWebAPI:1", "urn:schemas-sony-com:service:IRCC:1" };
                    for (int round = 0; round < 2; round++) {
                        for (String st : targets) {
                            String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: "
                                    + st + "\r\n\r\n";
                            byte[] d = msg.getBytes(StandardCharsets.US_ASCII);
                            sock.send(new DatagramPacket(d, d.length, group, 1900));
                        }
                    }
                    long end = System.currentTimeMillis() + 3000;
                    byte[] buf = new byte[4096];
                    while (System.currentTimeMillis() < end) {
                        try {
                            DatagramPacket pk = new DatagramPacket(buf, buf.length);
                            sock.receive(pk);
                            String r = new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
                            if (r.contains("sony") && pk.getAddress() != null) ips.add(pk.getAddress().getHostAddress());
                        } catch (SocketTimeoutException t) {
                            // keep listening until the 3 seconds are up
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (lock != null) { try { lock.release(); } catch (Exception ignored) { } }
                }
                JSONArray arr = new JSONArray();
                for (String ip : ips) arr.put(ip);
                final String js = "window.__nativeFound(" + JSONObject.quote(id) + "," + arr.toString() + ")";
                main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
            });
        }

        // ---------- Play on TV (real casting) ----------

        /** Starts looking for Chromecast TVs; results go to window.__castDevices. */
        @JavascriptInterface
        public void castScan() {
            main.post(() -> {
                CastHelper h = CastHelper.get(MainActivity.this);
                String err = h.init();
                if (err != null) { castListener.onState(CastHelper.error(err)); return; }
                h.setListener(castListener);
                h.startScan();
            });
        }

        @JavascriptInterface
        public void castStopScan() {
            main.post(() -> CastHelper.get(MainActivity.this).stopScan());
        }

        /** Re-sends what is playing (used when the app opens). */
        @JavascriptInterface
        public void castStatus() {
            main.post(() -> {
                CastHelper h = CastHelper.get(MainActivity.this);
                if (h.init() == null) h.setListener(castListener);
            });
        }

        /** Opens the phone's photo/video picker. */
        @JavascriptInterface
        public void pickMedia() {
            main.post(() -> {
                askNotificationPermission();
                Intent i;
                if (Build.VERSION.SDK_INT >= 33) {
                    i = new Intent("android.provider.action.PICK_IMAGES");
                } else {
                    i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
                }
                try {
                    startActivityForResult(i, REQ_PICK);
                } catch (Exception e) {
                    try {
                        Intent f = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        f.addCategory(Intent.CATEGORY_OPENABLE);
                        f.setType("*/*");
                        f.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"video/*", "image/*"});
                        startActivityForResult(f, REQ_PICK);
                    } catch (Exception e2) {
                        castListener.onState(CastHelper.error("Couldn't open your gallery."));
                    }
                }
            });
        }

        @JavascriptInterface
        public void castPlay(final String routeId) {
            main.post(() -> {
                askNotificationPermission();
                CastHelper h = CastHelper.get(MainActivity.this);
                String err = h.init();
                if (err != null) { castListener.onState(CastHelper.error(err)); return; }
                h.setListener(castListener);
                h.play(routeId);
            });
        }

        @JavascriptInterface
        public void castToggle() {
            main.post(() -> CastHelper.get(MainActivity.this).toggle());
        }

        @JavascriptInterface
        public void castStop() {
            main.post(() -> CastHelper.get(MainActivity.this).stop());
        }

        /** Opens Tailscale. If it isn't installed, opens its Play Store page and returns false. */
        @JavascriptInterface
        public boolean openTailscale() {
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("com.tailscale.ipn");
                if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; }
            } catch (Exception ignored) { }
            try {
                Intent store = new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.tailscale.ipn"));
                store.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(store);
            } catch (Exception e) {
                try {
                    Intent web = new Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.tailscale.ipn"));
                    web.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(web);
                } catch (Exception ignored) { }
            }
            return false;
        }

        /** Opens the phone's own screen-cast / Smart View screen. Returns false if none was found. */
        @JavascriptInterface
        public boolean castScreen() {
            String[] actions = { "android.settings.CAST_SETTINGS", "android.settings.WIFI_DISPLAY_SETTINGS" };
            for (String a : actions) {
                try {
                    Intent i = new Intent(a);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    return true;
                } catch (Exception ignored) { }
            }
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.chromecast.app");
                if (i != null) { startActivity(i); return true; }
            } catch (Exception ignored) { }
            return false;
        }
    }
}

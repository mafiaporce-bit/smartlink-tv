package com.jpsums.smartlinktv;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.HapticFeedbackConstants;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * SmartLink TV — the remote screen is the HTML page in assets/index.html.
 * The page talks to the Sony TV through the "Native" bridge below, because a
 * normal web page is not allowed to send requests to devices on your Wi-Fi.
 */
public class MainActivity extends Activity {

    private WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    /** Remote key presses go one after another on their own thread, so they stay in order and fast. */
    private final ExecutorService keys = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setTextZoom(100);
        web.setBackgroundColor(0xFF0D1117);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "Native");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    @SuppressWarnings("deprecation")
    @Override
    public void onBackPressed() {
        web.evaluateJavascript("(window.onNativeBack && window.onNativeBack()) ? 'yes' : 'no'", value -> {
            if (value == null || !value.contains("yes")) MainActivity.super.onBackPressed();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.evaluateJavascript("window.onNativeResume && window.onNativeResume()", null);
    }

    @Override
    protected void onDestroy() {
        pool.shutdownNow();
        keys.shutdownNow();
        super.onDestroy();
    }

    private static String readAll(InputStream is) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        while ((n = is.read(buf)) != -1) out.write(buf, 0, n);
        is.close();
        return out.toString("UTF-8");
    }

    private class Bridge {

        /** HTTP request to the TV. Result comes back via window.__nativeDone(id, status, body). */
        @JavascriptInterface
        public void request(final String id, final String url, final String method,
                            final String headersJson, final String body) {
            ExecutorService runner = url != null && url.endsWith("/sony/ircc") ? keys : pool;
            runner.execute(() -> {
                int status = -1;
                String text = "";
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setConnectTimeout(4000);
                    c.setReadTimeout(7000);
                    c.setRequestMethod(method == null || method.isEmpty() ? "POST" : method);
                    JSONObject h = new JSONObject(headersJson == null || headersJson.isEmpty() ? "{}" : headersJson);
                    Iterator<String> it = h.keys();
                    while (it.hasNext()) {
                        String k = it.next();
                        c.setRequestProperty(k, h.getString(k));
                    }
                    if (body != null && !body.isEmpty()) {
                        byte[] data = body.getBytes(StandardCharsets.UTF_8);
                        c.setDoOutput(true);
                        c.setFixedLengthStreamingMode(data.length);
                        try (OutputStream os = c.getOutputStream()) { os.write(data); }
                    }
                    status = c.getResponseCode();
                    InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (is != null) text = readAll(is);
                } catch (Exception e) {
                    status = -1;
                    text = String.valueOf(e.getMessage());
                    if (c != null) c.disconnect();
                }
                // No disconnect() on success: the connection is kept open and reused for the next press.
                final String js = "window.__nativeDone(" + JSONObject.quote(id) + "," + status + ","
                        + JSONObject.quote(text) + ")";
                main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
            });
        }

        @JavascriptInterface
        public void haptic() {
            main.post(() -> { if (web != null) web.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP); });
        }

        @JavascriptInterface
        public boolean isApp() { return true; }

        /** Looks for Sony TVs on the Wi-Fi (SSDP). Result: window.__nativeFound(id, ["192.168.0.148", ...]). */
        @JavascriptInterface
        public void discover(final String id) {
            pool.execute(() -> {
                LinkedHashSet<String> ips = new LinkedHashSet<>();
                WifiManager.MulticastLock lock = null;
                try {
                    WifiManager wm = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                    if (wm != null) {
                        lock = wm.createMulticastLock("smartlink");
                        lock.setReferenceCounted(false);
                        lock.acquire();
                    }
                } catch (Exception ignored) { }
                try (DatagramSocket sock = new DatagramSocket()) {
                    sock.setSoTimeout(500);
                    InetAddress group = InetAddress.getByName("239.255.255.250");
                    String[] targets = { "urn:schemas-sony-com:service:ScalarWebAPI:1", "urn:schemas-sony-com:service:IRCC:1" };
                    for (int round = 0; round < 2; round++) {
                        for (String st : targets) {
                            String msg = "M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 1\r\nST: "
                                    + st + "\r\n\r\n";
                            byte[] d = msg.getBytes(StandardCharsets.US_ASCII);
                            sock.send(new DatagramPacket(d, d.length, group, 1900));
                        }
                    }
                    long end = System.currentTimeMillis() + 3000;
                    byte[] buf = new byte[4096];
                    while (System.currentTimeMillis() < end) {
                        try {
                            DatagramPacket pk = new DatagramPacket(buf, buf.length);
                            sock.receive(pk);
                            String r = new String(pk.getData(), 0, pk.getLength(), StandardCharsets.UTF_8).toLowerCase(Locale.ROOT);
                            if (r.contains("sony") && pk.getAddress() != null) ips.add(pk.getAddress().getHostAddress());
                        } catch (SocketTimeoutException t) {
                            // keep listening until the 3 seconds are up
                        }
                    }
                } catch (Exception ignored) {
                } finally {
                    if (lock != null) { try { lock.release(); } catch (Exception ignored) { } }
                }
                JSONArray arr = new JSONArray();
                for (String ip : ips) arr.put(ip);
                final String js = "window.__nativeFound(" + JSONObject.quote(id) + "," + arr.toString() + ")";
                main.post(() -> { if (web != null) web.evaluateJavascript(js, null); });
            });
        }

        /** Opens the phone's own screen-cast / Smart View screen. Returns false if none was found. */
        @JavascriptInterface
        public boolean castScreen() {
            String[] actions = { "android.settings.CAST_SETTINGS", "android.settings.WIFI_DISPLAY_SETTINGS" };
            for (String a : actions) {
                try {
                    Intent i = new Intent(a);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                    return true;
                } catch (Exception ignored) { }
            }
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("com.google.android.apps.chromecast.app");
                if (i != null) { startActivity(i); return true; }
            } catch (Exception ignored) { }
            return false;
        }
    }
}

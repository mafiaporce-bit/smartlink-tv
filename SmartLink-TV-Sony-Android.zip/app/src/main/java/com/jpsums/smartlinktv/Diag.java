package com.jpsums.smartlinktv;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.LinkProperties;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.RouteInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.PowerManager;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.Inet4Address;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

import javax.net.SocketFactory;

/**
 * The app's own "check-up". When the TV can't be reached, this finds out WHY:
 * is it the phone's Wi-Fi, the phone blocking the app, the router, or the TV itself?
 * It also keeps a short diary of Wi-Fi drops, shown under Help.
 */
final class Diag {

    private static final ArrayDeque<String> diary = new ArrayDeque<>();
    private static final ExecutorService probes = Executors.newCachedThreadPool();
    private static volatile boolean blocked;
    private static volatile boolean watching;
    private static String lastRoute = "";
    private static int wifiInternet = -1;   // -1 unknown, 0 no, 1 yes

    private Diag() { }

    /** Writes a line in the diary, e.g. "22:43:05 Wi-Fi lost". */
    static synchronized void note(String what) {
        String t = new SimpleDateFormat("HH:mm:ss", Locale.US).format(new Date());
        diary.addLast(t + " " + what);
        while (diary.size() > 40) diary.removeFirst();
    }

    static synchronized void wifiInternet(boolean ok) {
        int now = ok ? 1 : 0;
        if (now == wifiInternet) return;
        boolean first = wifiInternet == -1;
        wifiInternet = now;
        if (!first || !ok) note(ok ? "Wi-Fi: internet OK again" : "Wi-Fi: no internet");
    }

    static synchronized void wifiGone() { wifiInternet = -1; }

    /** Watches which network the phone gives the app, and whether the phone is blocking the app. */
    static void watch(ConnectivityManager cm) {
        if (watching || cm == null) return;
        watching = true;
        try {
            cm.registerDefaultNetworkCallback(new ConnectivityManager.NetworkCallback() {
                @Override
                public void onCapabilitiesChanged(Network network, NetworkCapabilities caps) {
                    route(Net.nameOf(caps));
                }

                @Override
                public void onLost(Network network) {
                    route("none");
                }

                @Override
                public void onBlockedStatusChanged(Network network, boolean isBlocked) {
                    if (isBlocked == blocked) return;
                    blocked = isBlocked;
                    note(isBlocked ? "Phone BLOCKED this app's network" : "Phone un-blocked this app's network");
                }
            });
        } catch (Exception e) {
            watching = false;
        }
    }

    private static synchronized void route(String name) {
        if (name.equals(lastRoute)) return;
        boolean first = lastRoute.isEmpty();
        lastRoute = name;
        if (!first) note("Phone now uses: " + name);
    }

    /** Tries to open a connection. "ok" and "refused" both mean the device is there and awake. */
    private static String knock(SocketFactory over, String ip, int port, int ms) {
        Socket s = null;
        try {
            s = over != null ? over.createSocket() : new Socket();
            s.connect(new InetSocketAddress(ip, port), ms);
            return "ok";
        } catch (SocketTimeoutException e) {
            return "timeout";
        } catch (Exception e) {
            String m = String.valueOf(e.getMessage());
            if (m.contains("ECONNREFUSED") || m.toLowerCase(Locale.ROOT).contains("refused")) return "refused";
            if (m.contains("EHOSTUNREACH") || m.contains("No route")) return "unreachable";
            if (m.contains("ENETUNREACH") || m.contains("Network is unreachable")) return "nonet";
            if (m.contains("EPERM") || m.contains("EACCES")) return "blocked";
            return "fail";
        } finally {
            if (s != null) {
                try { s.close(); } catch (Exception ignored) { }
            }
        }
    }

    private static String get(Future<String> f) {
        try {
            return f.get(2600, TimeUnit.MILLISECONDS);
        } catch (Exception e) {
            return "timeout";
        }
    }

    /**
     * Runs the check-up (takes about 2 seconds, call from a background thread).
     * @param mainPort the TV's remote-control door (Sony 80, Samsung 8001)
     * @param otherPort another door on the same TV (Chromecast 8009, Samsung 8002) — tells "TV off" from "TV busy"
     * @param casting true while a video or photo is playing on the TV
     */
    static JSONObject checkup(Context c, String tvIp, int mainPort, int otherPort, boolean casting) {
        JSONObject o = new JSONObject();
        try {
            Context app = c.getApplicationContext();
            ConnectivityManager cm = (ConnectivityManager) app.getSystemService(Context.CONNECTIVITY_SERVICE);
            Network wifi = Net.wifiNetwork();
            final SocketFactory over = Net.socketFactory(tvIp);

            // the router's address
            String router = null;
            try {
                LinkProperties lp = cm != null && wifi != null ? cm.getLinkProperties(wifi) : null;
                if (lp != null) {
                    for (RouteInfo r : lp.getRoutes()) {
                        if (r.isDefaultRoute() && r.getGateway() instanceof Inet4Address) router = r.getGateway().getHostAddress();
                    }
                }
            } catch (Exception ignored) { }
            if (router == null && tvIp != null && tvIp.lastIndexOf('.') > 0) router = tvIp.substring(0, tvIp.lastIndexOf('.')) + ".1";
            final String gw = router;

            Future<String> tvMain = probes.submit(() -> knock(over, tvIp, mainPort, 2000));
            Future<String> tvOther = probes.submit(() -> knock(over, tvIp, otherPort, 2000));
            Future<String> gw1 = probes.submit(() -> gw == null ? "fail" : knock(over, gw, 53, 2000));
            Future<String> gw2 = probes.submit(() -> gw == null ? "fail" : knock(over, gw, 80, 2000));

            o.put("tv", get(tvMain));
            o.put("tv2", get(tvOther));
            String r1 = get(gw1), r2 = get(gw2);
            boolean routerUp = "ok".equals(r1) || "refused".equals(r1) || "ok".equals(r2) || "refused".equals(r2);
            o.put("router", routerUp ? "ok" : r1);
            o.put("routerIp", gw == null ? "" : gw);

            o.put("wifi", wifi != null);
            o.put("phoneIp", String.valueOf(MediaServer.wifiIp()));
            boolean internet = false;
            try {
                NetworkCapabilities caps = cm != null && wifi != null ? cm.getNetworkCapabilities(wifi) : null;
                internet = caps != null && caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED);
            } catch (Exception ignored) { }
            o.put("wifiInternet", internet);
            try {
                WifiManager wm = (WifiManager) app.getSystemService(Context.WIFI_SERVICE);
                @SuppressWarnings("deprecation")
                WifiInfo wi = wm == null ? null : wm.getConnectionInfo();
                if (wi != null) {
                    o.put("signal", wi.getRssi());
                    o.put("speed", wi.getLinkSpeed());
                    o.put("band", wi.getFrequency());
                }
            } catch (Exception ignored) { }

            o.put("route", Net.routeName());
            o.put("blocked", blocked);
            try {
                PowerManager pm = (PowerManager) app.getSystemService(Context.POWER_SERVICE);
                if (pm != null) {
                    o.put("saver", pm.isPowerSaveMode());
                    o.put("doze", pm.isDeviceIdleMode());
                    o.put("exempt", pm.isIgnoringBatteryOptimizations(app.getPackageName()));
                    o.put("screenOn", pm.isInteractive());
                }
            } catch (Exception ignored) { }

            o.put("casting", casting);
            long sent = MediaServer.lastSentAt;
            o.put("streamAgo", sent == 0 ? -1 : System.currentTimeMillis() - sent);
            o.put("lastErr", TvHttp.lastError());
            o.put("rescued", TvHttp.rescued());
            o.put("android", Build.VERSION.SDK_INT);
            o.put("diary", diary());
        } catch (Exception ignored) { }
        return o;
    }

    static synchronized JSONArray diary() {
        JSONArray a = new JSONArray();
        for (String line : diary) a.put(line);
        return a;
    }
}

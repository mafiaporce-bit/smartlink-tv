package com.jpsums.smartlinktv;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.DatagramSocket;
import java.net.HttpURLConnection;
import java.net.SocketTimeoutException;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;

/**
 * Sends one request to the TV and tries again by itself when the first try hits a
 * "dead line" — for example an old connection the TV closed while the phone was asleep,
 * or the phone sending through mobile data instead of Wi-Fi.
 *
 * Plain Java only (no Android classes) so it can be tested on a computer.
 * The Android side (see Net) plugs in how to open a connection over Wi-Fi.
 */
final class TvHttp {

    /** Opens a connection. preferWifi = go straight through the Wi-Fi when the address is in the home. */
    interface Opener { HttpURLConnection open(URL url, boolean preferWifi) throws IOException; }

    /** Ties a search socket to the Wi-Fi. */
    interface SocketPrep { void prep(DatagramSocket socket); }

    /** Says which network the phone is using right now ("wifi", "mobile"...), for the Help screen. */
    interface Label { String now(); }

    static volatile Opener opener = (url, preferWifi) -> (HttpURLConnection) url.openConnection();
    static volatile SocketPrep socketPrep = socket -> { };
    static volatile Label label = () -> "";

    static final int CONNECT_MS = 2500;
    static final int READ_MS = 7000;
    /** A new try is only started this soon after the first one began, so a TV that is really off is noticed quickly. */
    static final int RETRY_WINDOW_MS = 3500;
    private static final int MAX_TRIES = 3;

    // for the Help screen
    private static volatile String lastError = "";
    private static volatile long lastErrorAt;
    private static volatile String lastErrorNet = "";
    private static final java.util.concurrent.atomic.AtomicInteger rescued = new java.util.concurrent.atomic.AtomicInteger();

    static final class Reply {
        int status = -1;
        String text = "";
        int tries;
    }

    private TvHttp() { }

    /** True for addresses inside a home network (192.168.x.x, 10.x.x.x, 172.16-31.x.x, 169.254.x.x). */
    static boolean isLan(String host) {
        if (host == null) return false;
        String[] p = host.split("\\.");
        if (p.length != 4) return false;
        int a, b;
        try {
            a = Integer.parseInt(p[0]);
            b = Integer.parseInt(p[1]);
            Integer.parseInt(p[2]);
            Integer.parseInt(p[3]);
        } catch (NumberFormatException e) {
            return false;
        }
        return a == 10 || (a == 192 && b == 168) || (a == 172 && b >= 16 && b <= 31) || (a == 169 && b == 254);
    }

    /**
     * @param key true for a remote-button press. Those are only repeated when it is safe,
     *            so one tap can never become two presses on the TV.
     */
    static Reply send(String url, String method, Map<String, String> headers, String body, boolean key) {
        Reply out = new Reply();
        long began = System.currentTimeMillis();
        String problem = "";
        for (int attempt = 0; attempt < MAX_TRIES; attempt++) {
            out.tries = attempt + 1;
            boolean sent = false;
            long t0 = System.currentTimeMillis();
            HttpURLConnection c = null;
            try {
                // 1st try: straight over Wi-Fi. 2nd: the phone's normal route (a brand-new connection). 3rd: Wi-Fi again.
                c = opener.open(new URL(url), attempt != 1);
                c.setConnectTimeout(CONNECT_MS);
                c.setReadTimeout(READ_MS);
                c.setRequestMethod(method == null || method.isEmpty() ? "POST" : method);
                if (headers != null) {
                    for (Map.Entry<String, String> h : headers.entrySet()) c.setRequestProperty(h.getKey(), h.getValue());
                }
                // Button presses keep their connection open so the next press is instant.
                // Everything else hangs up afterwards, so no old connections are left lying around.
                if (!key) c.setRequestProperty("Connection", "close");
                if (body != null && !body.isEmpty()) {
                    byte[] data = body.getBytes(StandardCharsets.UTF_8);
                    c.setDoOutput(true);
                    c.setFixedLengthStreamingMode(data.length);
                    try (OutputStream os = c.getOutputStream()) { os.write(data); }
                    sent = true;
                }
                int status = c.getResponseCode();
                InputStream is = status >= 400 ? c.getErrorStream() : c.getInputStream();
                out.status = status;
                out.text = is == null ? "" : readAll(is);
                if (attempt > 0) rescued.incrementAndGet();
                return out;
            } catch (Exception e) {
                if (c != null) {
                    try { c.disconnect(); } catch (Exception ignored) { }
                }
                long now = System.currentTimeMillis();
                boolean timeout = e instanceof SocketTimeoutException;
                problem = e.getClass().getSimpleName() + (e.getMessage() == null ? "" : ": " + e.getMessage());
                out.status = -1;
                out.text = String.valueOf(e.getMessage());
                boolean safe;
                if (!sent) safe = true;                                  // the TV never got it
                else if (key) safe = !timeout && now - t0 < 1500;        // line dropped at once: the TV never saw the press
                else safe = true;                                        // status checks can always be asked again
                if (!safe || now - began > RETRY_WINDOW_MS) break;
            }
        }
        lastError = problem;
        lastErrorAt = System.currentTimeMillis();
        try { lastErrorNet = label.now(); } catch (Exception e) { lastErrorNet = ""; }
        return out;
    }

    static String lastError() { return lastError; }
    static long lastErrorAt() { return lastErrorAt; }
    static String lastErrorNet() { return lastErrorNet; }
    /** How many requests failed at first but worked on the automatic second try. */
    static int rescued() { return rescued.get(); }

    private static String readAll(InputStream is) throws IOException {
        try (InputStream in = is) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
                if (out.size() > 4_000_000) break;
            }
            return out.toString("UTF-8");
        }
    }
}
